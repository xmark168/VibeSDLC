# API Documentation: Forgot Password Endpoint

## POST /api/auth/forgot-password

Initiates the password reset process by sending a reset link to the user's email address.

### Request
- **URL:** `/api/auth/forgot-password`
- **Method:** `POST`
- **Content-Type:** `application/json`

#### Body Parameters
| Name  | Type   | Required | Description                       |
|-------|--------|----------|-----------------------------------|
| email | string | Yes      | Registered email address of user  |

Example:
```
{
  "email": "john@example.com"
}
```

### Validation
- `email` is required.
- `email` must be a valid email address.

### Response
- **Status:** `200 OK` (on success)
- **Content-Type:** `application/json`

#### Success Response
```
{
  "success": true,
  "message": "If an account with that email exists, a password reset link has been sent."
}
```

#### Error Responses
- `400 Bad Request`: Validation error
- `500 Internal Server Error`: Unexpected error

### Notes
- For security, the response is the same whether or not the email exists in the system.
- The endpoint does not reveal if the email is registered.
- Uses Joi for validation.
- Follows layered architecture: Controller → Service → Repository → Model.
