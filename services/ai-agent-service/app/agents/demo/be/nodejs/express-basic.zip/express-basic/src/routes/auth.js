const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validateRequest } = require('../middleware/validate');
const { loginRateLimiter } = require('../middleware/rateLimit');
const { authValidation } = require('../utils/validators');
const Joi = require('joi');

router.post('/register', validateRequest(authValidation.register), authController.registerUser);
// Login route (validation and controller to be implemented in later sub-steps)
router.post('/login', loginRateLimiter, (req, res, next) => {
  // Placeholder for login validation and controller
  res.status(501).json({ success: false, message: 'Not implemented' });
});

router.post('/forgot-password', validateRequest(Joi.object({ email: Joi.string().email().required() })), authController.forgotPassword);

router.post('/reset-password', validateRequest(authValidation.resetPassword), authController.resetPassword);

router.post('/refresh', authController.refreshToken);

module.exports = router;