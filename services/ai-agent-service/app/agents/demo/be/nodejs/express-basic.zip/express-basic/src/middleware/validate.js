const { AppError } = require('../utils/errors');

exports.validateRequest = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body, { abortEarly: false });
    if (error) {
      return next(new AppError(error.details.map(d => d.message).join(', '), 400));
    }
    next();
  };
};
