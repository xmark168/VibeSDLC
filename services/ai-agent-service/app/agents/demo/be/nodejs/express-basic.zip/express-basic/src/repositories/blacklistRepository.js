const mongoose = require('mongoose');

// BlacklistedToken model definition (inline for repository, model will be created in its step)
const BlacklistedToken = mongoose.models.BlacklistedToken || mongoose.model('BlacklistedToken', new mongoose.Schema({
  token: { type: String, required: true, unique: true },
  expiresAt: { type: Date, required: true },
}, { timestamps: true }));

class BlacklistRepository {
  async add(token, expiresAt) {
    return await BlacklistedToken.create({ token, expiresAt });
  }

  async isBlacklisted(token) {
    const found = await BlacklistedToken.findOne({ token });
    return !!found;
  }

  async removeExpired() {
    return await BlacklistedToken.deleteMany({ expiresAt: { $lte: new Date() } });
  }
}

module.exports = new BlacklistRepository();
