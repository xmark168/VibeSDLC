# API Documentation: Register Endpoint

## POST /api/auth/register

Registers a new user in the system.

### Request
- **URL:** `/api/auth/register`
- **Method:** `POST`
- **Content-Type:** `application/json`

#### Body Parameters
| Name     | Type   | Required | Description                  |
|----------|--------|----------|------------------------------|
| name     | string | Yes      | Full name of the user        |
| email    | string | Yes      | Email address (must be unique)|
| password | string | Yes      | Password (min 8 characters)  |

Example:
```
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```

### Validation
- All fields are required.
- `email` must be a valid email address and unique.
- `password` must be at least 8 characters.

### Response
- **Status:** `201 Created` (on success)
- **Content-Type:** `application/json`

#### Success Response
```
{
  "success": true,
  "data": {
    "user": {
      "id": "<user_id>",
      "name": "John Doe",
      "email": "john@example.com",
      "role": "user"
    },
    "token": "<jwt_token>"
  },
  "message": "User registered successfully"
}
```

#### Error Responses
- `409 Conflict`: User already exists
- `400 Bad Request`: Validation error
- `500 Internal Server Error`: Unexpected error

### Notes
- JWT token is returned for authentication.
- Password is never returned in the response.
- Uses Joi for validation.
- Follows layered architecture: Controller → Service → Repository → Model.
