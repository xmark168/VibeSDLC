# API Documentation: Reset Password Endpoint

## POST /api/auth/reset-password

Completes the password reset process by allowing the user to set a new password using a valid reset token.

### Request
- **URL:** `/api/auth/reset-password`
- **Method:** `POST`
- **Content-Type:** `application/json`

#### Body Parameters
| Name     | Type   | Required | Description                       |
|----------|--------|----------|-----------------------------------|
| token    | string | Yes      | Password reset token (from email) |
| password | string | Yes      | New password                      |

Example:
```
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6...",
  "password": "newStrongPassword123"
}
```

### Validation
- `token` is required.
- `password` is required and must meet password policy (e.g., minimum 8 characters).

### Response
- **Status:** `200 OK` (on success)
- **Content-Type:** `application/json`

#### Success Response
```
{
  "success": true,
  "message": "Password has been reset successfully."
}
```

#### Error Responses
- `400 Bad Request`: Validation error or invalid/expired token
- `404 Not Found`: User not found
- `500 Internal Server Error`: Unexpected error

### Notes
- The reset token is typically sent to the user's email via the forgot-password endpoint.
- The endpoint validates the token and updates the user's password.
- Uses Joi for validation.
- Follows layered architecture: Controller → Service → Repository → Model.