const userRepository = require('../repositories/userRepository');
const crypto = require('crypto');
const refreshTokenRepository = require('../repositories/refreshTokenRepository');
const blacklistRepository = require('../repositories/blacklistRepository');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config');
const logger = require('../utils/logger');

class AuthService {
  _parseExpire(expireStr) {
    // Supports '7d', '1h', '30m', '60s' etc.
    const match = /^([0-9]+)([smhd])$/.exec(expireStr);
    if (!match) return 7 * 24 * 60 * 60 * 1000; // default 7d
    const value = parseInt(match[1], 10);
    switch (match[2]) {
      case 's': return value * 1000;
      case 'm': return value * 60 * 1000;
      case 'h': return value * 60 * 60 * 1000;
      case 'd': return value * 24 * 60 * 60 * 1000;
      default: return 7 * 24 * 60 * 60 * 1000;
    }
  }

  async loginUser(loginData) {
    const { email, password } = loginData;
    const user = await userRepository.findByEmail(email);
    if (!user) {
      logger.error(`Failed login attempt: email=${email} - user not found`);
      const error = new Error('Invalid credentials');
      error.statusCode = 401;
      throw error;
    }
    const passwordMatch = await this.comparePassword(password, user.password);
    if (!passwordMatch) {
      logger.error(`Failed login attempt: email=${email} - incorrect password`);
      const error = new Error('Invalid credentials');
      error.statusCode = 401;
      throw error;
    }
    const accessToken = jwt.sign({ id: user._id }, config.JWT_SECRET, { expiresIn: config.JWT_EXPIRE });
    const refreshTokenValue = crypto.randomBytes(40).toString('hex');
    const refreshTokenExpiresAt = new Date(Date.now() + this._parseExpire(config.JWT_REFRESH_EXPIRE));
    await refreshTokenRepository.save({
      userId: user._id,
      token: refreshTokenValue,
      expiresAt: refreshTokenExpiresAt,
      revoked: false
    });
    return { user, accessToken, refreshToken: refreshTokenValue };
  }

  async registerUser(userData) {
    // Check if user already exists
    const existingUser = await userRepository.findByEmail(userData.email);
    if (existingUser) {
      const error = new Error('User already exists');
      error.statusCode = 409;
      throw error;
    }

    // Hash password
    const saltRounds = 12;
    userData.password = await bcrypt.hash(userData.password, saltRounds);

    // Create user
    const newUser = await userRepository.create(userData);

    // Generate JWT token
    const token = jwt.sign({ id: newUser._id }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    return { user: newUser, token };
  }

  async comparePassword(plainPassword, hashedPassword) {
    return await bcrypt.compare(plainPassword, hashedPassword);
  }

  async refreshToken(refreshToken) {
    // Find refresh token document
    // Check blacklist first
    const isBlacklisted = await blacklistRepository.isBlacklisted(refreshToken);
    if (isBlacklisted) {
      logger.error(`Refresh token is blacklisted: ${refreshToken}`);
      const error = new Error('Invalid or expired refresh token');
      error.statusCode = 401;
      throw error;
    }
    const tokenDoc = await refreshTokenRepository.findByToken(refreshToken);
    if (!tokenDoc || tokenDoc.revoked || tokenDoc.expiresAt < new Date()) {
      logger.error(`Invalid or expired refresh token: ${refreshToken}`);
      const error = new Error('Invalid or expired refresh token');
      error.statusCode = 401;
      throw error;
    }

    // Find user
    const user = await userRepository.findById(tokenDoc.userId);
    if (!user) {
      logger.error(`Refresh token user not found: userId=${tokenDoc.userId}`);
      const error = new Error('User not found');
      error.statusCode = 404;
      throw error;
    }

    // Generate new access token
    const accessToken = jwt.sign({ id: user._id }, config.JWT_SECRET, {
      expiresIn: config.JWT_EXPIRE,
    });

    // Generate new refresh token
    const refreshTokenValue = require('crypto').randomBytes(40).toString('hex');
    const refreshTokenExpiresAt = new Date(Date.now() + this._parseExpire(config.JWT_REFRESH_EXPIRE));
    await refreshTokenRepository.save({
      userId: user._id,
      token: refreshTokenValue,
      expiresAt: refreshTokenExpiresAt,
      revoked: false
    });

    // Invalidate the old refresh token
    await refreshTokenRepository.invalidate(refreshToken);

    return { accessToken, refreshToken: refreshTokenValue };
  }
}

module.exports = new AuthService();
