const authService = require('../services/authService');
const passwordResetService = require('../services/passwordResetService');
const userRepository = require('../repositories/userRepository');
const sendEmail = require('../utils/email/sendEmail');
const { AppError } = require('../utils/errors');

exports.registerUser = async (req, res, next) => {
  try {
    const result = await authService.registerUser(req.body);
    return res.status(201).json({
      success: true,
      data: result,
      message: 'User registered successfully',
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Handles password reset requests with token validation
 * @route POST /api/auth/reset-password
 */
exports.resetPassword = async (req, res, next) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) {
      throw new AppError('Token and new password are required', 400);
    }
    await passwordResetService.resetPassword(token, newPassword);
    return res.status(200).json({
      success: true,
      message: 'Password has been reset successfully',
    });
  } catch (error) {
    if (!(error instanceof AppError)) {
      return next(new AppError(error.message || 'Invalid or expired token', 400));
    }
    next(error);
  }
};

/**
 * Handles refresh token requests
 * @route POST /api/auth/refresh
 */
exports.refreshToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      return res.status(400).json({
        success: false,
        message: 'Refresh token is required',
      });
    }
    const result = await authService.refreshToken(refreshToken);
    return res.status(200).json({
      success: true,
      data: result,
      message: 'Token refreshed successfully',
    });
  } catch (error) {
    if (!(error instanceof AppError)) {
      return res.status(error.statusCode === 401 ? 401 : 400).json({
        success: false,
        message: error.message || 'Invalid or expired refresh token',
      });
    }
    next(error);
  }
};

exports.loginUser = async (req, res, next) => {
  try {
    const result = await authService.loginUser(req.body);
    return res.status(200).json({
      success: true,
      data: result,
      message: 'Login successful',
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Handles forgot password requests and sends reset email
 * @route POST /api/auth/forgot-password
 */
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) {
      throw new AppError('Email is required', 400);
    }
    // Find user by email
    const user = await userRepository.findByEmail(email);
    if (!user) {
      throw new AppError('No user found with that email', 404);
    }
    // Generate reset token
    const token = await passwordResetService.generateResetToken(user._id);
    // Build reset URL (frontend should handle this route)
    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${token}`;
    // Email content
    const subject = 'Password Reset Request';
    const html = `<p>Hello ${user.name || 'User'},</p>
      <p>You requested a password reset. Click the link below to reset your password:</p>
      <p><a href="${resetUrl}">Reset Password</a></p>
      <p>If you did not request this, please ignore this email.</p>`;
    // Send email
    await sendEmail(user.email, subject, html);
    return res.status(200).json({
      success: true,
      message: 'Password reset email sent',
    });
  } catch (error) {
    next(error);
  }
};
