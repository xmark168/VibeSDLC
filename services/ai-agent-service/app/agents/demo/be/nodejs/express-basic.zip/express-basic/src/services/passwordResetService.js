const crypto = require('crypto');
const passwordResetTokenRepository = require('../repositories/passwordResetTokenRepository');
const userRepository = require('../repositories/userRepository');
const bcrypt = require('bcryptjs');

class PasswordResetService {
  /**
   * Resets the user's password and invalidates the reset token.
   * @param {string} token - The reset token
   * @param {string} newPassword - The new password to set
   * @returns {Promise<void>}
   * @throws {Error} If token is invalid/expired or user not found
   */
  async resetPassword(token, newPassword) {
    // Validate token
    const tokenDoc = await this.validateResetToken(token);
    // Find user
    const userId = tokenDoc.userId;
    // Hash new password
    const saltRounds = 12;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    // Update user password
    await userRepository.updatePasswordById(userId, hashedPassword);
    // Invalidate token
    await passwordResetTokenRepository.invalidateToken(token);
  }

  /**
   * Generates a secure random token, saves it with userId and expiry, and returns the token.
   * @param {string} userId - The user's MongoDB ObjectId
   * @returns {Promise<string>} The generated reset token
   */
  async generateResetToken(userId) {
    // Generate a secure random token
    const token = crypto.randomBytes(32).toString('hex');
    // Set expiry (e.g., 1 hour from now)
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

    // Save token to DB
    await passwordResetTokenRepository.saveToken({
      userId,
      token,
      expiresAt,
    });

    return token;
  }

  /**
   * Validates a password reset token and checks its expiration.
   * @param {string} token - The reset token to validate
   * @returns {Promise<Object>} The token document if valid
   * @throws {Error} If token is invalid or expired
   */
  async validateResetToken(token) {
    const tokenDoc = await passwordResetTokenRepository.findByToken(token);
    if (!tokenDoc) {
      throw new Error('Invalid or expired reset token');
    }
    if (tokenDoc.expiresAt < new Date()) {
      throw new Error('Reset token has expired');
    }
    return tokenDoc;
  }
}

module.exports = new PasswordResetService();
