const PasswordResetToken = require('../models/PasswordResetToken');

class PasswordResetTokenRepository {
  async findByToken(token) {
    return await PasswordResetToken.findOne({ token }).lean();
  }

  async saveToken(tokenData) {
    const token = new PasswordResetToken(tokenData);
    await token.save();
    return token.toObject();
  }

  async invalidateToken(token) {
    await PasswordResetToken.deleteOne({ token });
  }
}

module.exports = new PasswordResetTokenRepository();