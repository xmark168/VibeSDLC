const User = require('../models/User');

class UserRepository {
  async updatePasswordById(userId, hashedPassword) {
    await User.updateOne({ _id: userId }, { $set: { password: hashedPassword } });
  }

  async findByEmail(email) {
    return await User.findOne({ email }).lean();
  }

  async create(userData) {
    const user = new User(userData);
    await user.save();
    return user.toObject();
  }
}

module.exports = new UserRepository();