function passwordResetTemplate({ name, resetLink }) {
  return `
    <div style="font-family: Arial, sans-serif; color: #222;">
      <h2>Password Reset Request</h2>
      <p>Hi ${name || 'User'},</p>
      <p>We received a request to reset your password. Click the button below to set a new password:</p>
      <p style="margin: 24px 0;">
        <a href="${resetLink}" style="background: #007bff; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
      </p>
      <p>If you did not request a password reset, please ignore this email. Your password will remain unchanged.</p>
      <hr style="margin: 32px 0; border: none; border-top: 1px solid #eee;" />
      <small>If you have any questions, contact our support team.</small>
    </div>
  `;
}

module.exports = passwordResetTemplate;
