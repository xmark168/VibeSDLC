const request = require('supertest');
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const authRoutes = require('../../routes/auth');
const User = require('../../models/User');
const PasswordResetToken = require('../../models/PasswordResetToken');
const bcrypt = require('bcryptjs');

const app = express();
app.use(bodyParser.json());
app.use('/api/auth', authRoutes);

// Setup and teardown for DB
beforeAll(async () => {
  await mongoose.connect('mongodb://localhost:27017/test-vibesdlc', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
});

afterAll(async () => {
  await mongoose.connection.db.dropDatabase();
  await mongoose.disconnect();
});

describe('POST /api/auth/reset-password', () => {
  let user;
  let validToken;

  beforeEach(async () => {
    await User.deleteMany({});
    await PasswordResetToken.deleteMany({});
    // Create a user
    user = await User.create({
      email: 'resetuser@example.com',
      password: await bcrypt.hash('OldPassword123', 12),
    });
    // Create a valid token
    validToken = 'valid-token-123';
    await PasswordResetToken.create({
      userId: user._id,
      token: validToken,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
    });
  });

  afterEach(async () => {
    await User.deleteMany({});
    await PasswordResetToken.deleteMany({});
  });

  it('should reset password with valid token', async () => {
    const res = await request(app)
      .post('/api/auth/reset-password')
      .send({
        token: validToken,
        newPassword: 'NewStrongPassword123',
      });
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('message', 'Password has been reset successfully');
    // Token should be invalidated
    const tokenDoc = await PasswordResetToken.findOne({ token: validToken });
    expect(tokenDoc).toBeNull();
    // Password should be updated
    const updatedUser = await User.findById(user._id).select('+password');
    const isMatch = await bcrypt.compare('NewStrongPassword123', updatedUser.password);
    expect(isMatch).toBe(true);
  });

  it('should return 400 for invalid token', async () => {
    const res = await request(app)
      .post('/api/auth/reset-password')
      .send({
        token: 'invalid-token-456',
        newPassword: 'NewStrongPassword123',
      });
    expect(res.statusCode).toBe(400);
    expect(res.body).toHaveProperty('error');
    expect(res.body.error).toMatch(/Invalid or expired token|Reset token has expired/);
  });

  it('should return 400 for expired token', async () => {
    // Create an expired token
    const expiredToken = 'expired-token-789';
    await PasswordResetToken.create({
      userId: user._id,
      token: expiredToken,
      expiresAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
    });
    const res = await request(app)
      .post('/api/auth/reset-password')
      .send({
        token: expiredToken,
        newPassword: 'NewStrongPassword123',
      });
    expect(res.statusCode).toBe(400);
    expect(res.body).toHaveProperty('error');
    expect(res.body.error).toMatch(/Invalid or expired token|Reset token has expired/);
  });

  it('should return 400 for missing token or password', async () => {
    const res1 = await request(app)
      .post('/api/auth/reset-password')
      .send({ token: validToken });
    expect(res1.statusCode).toBe(400);
    expect(res1.body).toHaveProperty('error');
    expect(res1.body.error).toMatch(/Token and new password are required/);

    const res2 = await request(app)
      .post('/api/auth/reset-password')
      .send({ newPassword: 'NewStrongPassword123' });
    expect(res2.statusCode).toBe(400);
    expect(res2.body).toHaveProperty('error');
    expect(res2.body.error).toMatch(/Token and new password are required/);
  });
});
