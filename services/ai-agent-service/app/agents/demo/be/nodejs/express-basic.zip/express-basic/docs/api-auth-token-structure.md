# Token Structure Documentation

## Access Token (JWT)

- **Format:** JSON Web Token (JWT)
- **Type:** String
- **Usage:** Sent in the `Authorization` header as `Bearer <accessToken>` for authenticated requests.
- **Payload Claims:**
  - `id`: User ID (MongoDB ObjectId)
  - (Optional) Other claims as configured
- **Example:**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY0YzYyYzYyYzYyYzYyYzYyYzYyYzYyYzYyIiwiaWF0IjoxNjg1NjQwODAwLCJleHAiOjE2ODU2NDQ0MDB9.abc123signature
```
- **Expiration:** Configurable (default: 1 hour)
- **Storage:** Should be stored in memory (not persisted) by the client.

---

## Refresh Token

- **Format:** Random hex string (not JWT)
- **Type:** String
- **Usage:** Sent in the request body to `/api/auth/refresh` to obtain new access/refresh tokens.
- **Database Schema:**
  - `userId`: MongoDB ObjectId (reference to User)
  - `token`: String (random, 40 bytes hex)
  - `expiresAt`: Date
  - `revoked`: Boolean
- **Example:**
```
3f8e1a2b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f
```
- **Expiration:** Configurable (default: 7 days)
- **Storage:** Should be securely persisted by the client (e.g., HTTP-only cookie or secure local storage).

---

## Token Lifecycle

- **Access Token:** Short-lived, used for API authentication. Expires quickly for security.
- **Refresh Token:** Long-lived, used to obtain new access tokens. Invalidated after use (rotated).
- **Security:**
  - Never expose refresh tokens to client-side JavaScript if possible.
  - Always transmit tokens over HTTPS.
  - Old refresh tokens are revoked after rotation.

---

## Example Response (Refresh)

```
{
  "success": true,
  "data": {
    "accessToken": "<new_access_token>",
    "refreshToken": "<new_refresh_token>"
  },
  "message": "Token refreshed successfully"
}
```

## Error Response (Invalid/Expired Token)

```
{
  "success": false,
  "error": "Invalid or expired refresh token"
}
```

---

## References
- [JWT RFC 7519](https://datatracker.ietf.org/doc/html/rfc7519)
- [OWASP: JWT Security](https://cheatsheetseries.owasp.org/cheatsheets/JSON_Web_Token_for_Java_Cheat_Sheet.html)
