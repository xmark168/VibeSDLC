const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');
const User = require('../../src/models/User');
const PasswordResetToken = require('../../src/models/PasswordResetToken');
const sendEmail = require('../../src/utils/email/sendEmail');

jest.mock('../../src/utils/email/sendEmail');

const testUser = {
  email: 'forgotuser@example.com',
  password: 'ForgotPass123',
  name: 'Forgot User'
};

async function createTestUser() {
  await User.deleteMany({});
  const user = new User(testUser);
  await user.save();
  return user;
}

describe('POST /api/v1/auth/forgot-password', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGO_URI_TEST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  beforeEach(async () => {
    await User.deleteMany({});
    await PasswordResetToken.deleteMany({});
    sendEmail.mockClear();
  });

  it('should send password reset email and generate token for valid user', async () => {
    await createTestUser();
    const res = await request(app)
      .post('/api/v1/auth/forgot-password')
      .send({ email: testUser.email });
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.message).toBe('Password reset email sent');
    expect(sendEmail).toHaveBeenCalledTimes(1);
    // Token should be created in DB
    const user = await User.findOne({ email: testUser.email });
    const tokenDoc = await PasswordResetToken.findOne({ userId: user._id });
    expect(tokenDoc).not.toBeNull();
    expect(typeof tokenDoc.token).toBe('string');
    expect(tokenDoc.expiresAt).toBeInstanceOf(Date);
  });

  it('should return 404 for non-existent email', async () => {
    const res = await request(app)
      .post('/api/v1/auth/forgot-password')
      .send({ email: 'nouser@example.com' });
    expect(res.statusCode).toBe(404);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/No user found/);
    expect(sendEmail).not.toHaveBeenCalled();
  });

  it('should return 400 if email is missing', async () => {
    const res = await request(app)
      .post('/api/v1/auth/forgot-password')
      .send({});
    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Email is required/);
    expect(sendEmail).not.toHaveBeenCalled();
  });
});
