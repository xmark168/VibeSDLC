const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');
const User = require('../../src/models/User');
const RefreshToken = require('../../src/models/RefreshToken');
const blacklistRepository = require('../../src/repositories/blacklistRepository');

const testUser = {
  email: 'refreshtestuser@example.com',
  password: 'RefreshTestPass123'
};

async function registerAndLoginUser() {
  await request(app)
    .post('/register')
    .send(testUser);
  const loginRes = await request(app)
    .post('/login')
    .send({
      email: testUser.email,
      password: testUser.password,
    });
  return loginRes.body.data.refreshToken;
}

describe('POST /refresh', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGO_URI_TEST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  beforeEach(async () => {
    await User.deleteMany({});
    await RefreshToken.deleteMany({});
  });

  it('should return new access and refresh tokens for a valid refresh token', async () => {
    const refreshToken = await registerAndLoginUser();
    const res = await request(app)
      .post('/refresh')
      .send({ refreshToken });
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('accessToken');
    expect(res.body.data).toHaveProperty('refreshToken');
    expect(typeof res.body.data.accessToken).toBe('string');
    expect(typeof res.body.data.refreshToken).toBe('string');
    expect(res.body.message).toBe('Token refreshed successfully');
  });

  it('should return 401 and error for expired refresh token', async () => {
    await request(app)
      .post('/register')
      .send(testUser);
    const user = await User.findOne({ email: testUser.email });
    // Create an expired refresh token
    const expiredToken = new RefreshToken({
      userId: user._id,
      token: 'expired-refresh-token',
      expiresAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
      revoked: false
    });
    await expiredToken.save();
    const res = await request(app)
      .post('/refresh')
      .send({ refreshToken: 'expired-refresh-token' });
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Invalid or expired refresh token/);
  });

  it('should return 401 and error for revoked refresh token', async () => {
    await request(app)
      .post('/register')
      .send(testUser);
    const user = await User.findOne({ email: testUser.email });
    // Create a revoked refresh token
    const revokedToken = new RefreshToken({
      userId: user._id,
      token: 'revoked-refresh-token',
      expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
      revoked: true
    });
    await revokedToken.save();
    const res = await request(app)
      .post('/refresh')
      .send({ refreshToken: 'revoked-refresh-token' });
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Invalid or expired refresh token/);
  });

  it('should return 401 and error for blacklisted refresh token', async () => {
    await request(app)
      .post('/register')
      .send(testUser);
    const user = await User.findOne({ email: testUser.email });
    // Create a valid refresh token
    const validToken = new RefreshToken({
      userId: user._id,
      token: 'blacklisted-refresh-token',
      expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
      revoked: false
    });
    await validToken.save();
    // Blacklist the token
    await blacklistRepository.add('blacklisted-refresh-token', new Date(Date.now() + 60 * 60 * 1000));
    const res = await request(app)
      .post('/refresh')
      .send({ refreshToken: 'blacklisted-refresh-token' });
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Invalid or expired refresh token/);
  });
});
