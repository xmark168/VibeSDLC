const RefreshToken = require('../models/RefreshToken');

class RefreshTokenRepository {
  async isRevoked(token) {
    const tokenDoc = await RefreshToken.findOne({ token }).lean();
    return tokenDoc ? !!tokenDoc.revoked : false;
  }
  async findByToken(token) {
    return await RefreshToken.findOne({ token }).lean();
  }

  async findByUserId(userId) {
    return await RefreshToken.find({ userId, revoked: false, expiresAt: { $gt: new Date() } }).lean();
  }

  async save(tokenData) {
    const refreshToken = new RefreshToken(tokenData);
    await refreshToken.save();
    return refreshToken.toObject();
  }

  async invalidate(token) {
    return await RefreshToken.updateOne({ token }, { $set: { revoked: true } });
  }

  async invalidateAllForUser(userId) {
    return await RefreshToken.updateMany({ userId }, { $set: { revoked: true } });
  }
}

module.exports = new RefreshTokenRepository();
