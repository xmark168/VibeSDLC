const { AppError } = require('../utils/errors');

/**
 * Middleware to validate the format of the refresh token in request body
 * Assumes refresh token is sent in req.body.refreshToken
 */
module.exports = (req, res, next) => {
  const { refreshToken } = req.body;
  // Basic format validation: must be a non-empty string, typical JWT length > 20
  if (!refreshToken || typeof refreshToken !== 'string' || refreshToken.length < 20) {
    return next(new AppError('Invalid refresh token format', 400));
  }
  // Optionally: check for JWT structure (three parts separated by dots)
  const parts = refreshToken.split('.');
  if (parts.length !== 3) {
    return next(new AppError('Malformed refresh token', 400));
  }
  next();
};
