# API Documentation: Login Endpoint

## POST /api/auth/login

Authenticates a user and returns a JWT token.

### Request
- **URL:** `/api/auth/login`
- **Method:** `POST`
- **Content-Type:** `application/json`

#### Body Parameters
| Name     | Type   | Required | Description                  |
|----------|--------|----------|------------------------------|
| email    | string | Yes      | Email address (registered)   |
| password | string | Yes      | User's password              |

Example:
```
{
  "email": "john@example.com",
  "password": "password123"
}
```

### Validation
- Both fields are required.
- `email` must be a valid email address.
- `password` must be at least 8 characters.

### Response
- **Status:** `200 OK` (on success)
- **Content-Type:** `application/json`

#### Success Response
```
{
  "success": true,
  "data": {
    "user": {
      "id": "<user_id>",
      "name": "John Doe",
      "email": "john@example.com",
      "role": "user"
    },
    "token": "<jwt_token>"
  },
  "message": "Login successful"
}
```

#### Error Responses
- `401 Unauthorized`: Invalid credentials
- `400 Bad Request`: Validation error
- `500 Internal Server Error`: Unexpected error

### Notes
- JWT token is returned for authentication.
- Password is never returned in the response.
- Uses Joi for validation.
- Follows layered architecture: Controller → Service → Repository → Model.
