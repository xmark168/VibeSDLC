# POST /api/auth/refresh

Refresh the access token using a valid refresh token.

---

**Endpoint:**

    POST /api/auth/refresh

**Description:**

Exchanges a valid refresh token for a new access token (JWT). This endpoint is used to maintain user sessions without requiring the user to log in again. The refresh token must be sent in the request body.

**Request Body:**

```
{
  "refreshToken": "<refresh_token_string>"
}
```

**Response:**

- **200 OK**

```
{
  "success": true,
  "data": {
    "accessToken": "<new_access_token>",
    "refreshToken": "<new_refresh_token>"
  },
  "message": "Token refreshed successfully"
}
```

- **4xx/5xx Error**

```
{
  "success": false,
  "error": "Invalid or expired refresh token"
}
```

**Notes:**
- The old refresh token is invalidated after use.
- The new refresh token should be securely stored by the client.
- If the refresh token is invalid or expired, the user must log in again.

---

**Example Request:**

```
POST /api/auth/refresh
Content-Type: application/json

{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Example Success Response:**

```
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "message": "Token refreshed successfully"
}
```

**Example Error Response:**

```
{
  "success": false,
  "error": "Invalid or expired refresh token"
}
```
