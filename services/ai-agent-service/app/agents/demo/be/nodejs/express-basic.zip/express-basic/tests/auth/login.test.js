const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../../src/app');
const User = require('../../src/models/User');

// Test user credentials
const testUser = {
  email: 'loginuser@example.com',
  password: 'LoginPass123'
};

// Helper to register user before login
async function registerTestUser() {
  await request(app)
    .post('/register')
    .send(testUser);
}

describe('POST /login', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGO_URI_TEST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  beforeEach(async () => {
    await User.deleteMany({});
  });

  it('should login with valid credentials and return a JWT token', async () => {
    await registerTestUser();
    const res = await request(app)
      .post('/login')
      .send({
        email: testUser.email,
        password: testUser.password,
      });
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toHaveProperty('user');
    expect(res.body.data.user.email).toBe(testUser.email);
    expect(res.body.data).toHaveProperty('token');
    expect(typeof res.body.data.token).toBe('string');
    expect(res.body.message).toBe('Login successful');
  });

  it('should return 401 and error message for non-existent user', async () => {
    const res = await request(app)
      .post('/login')
      .send({
        email: 'nouser@example.com',
        password: 'SomePassword123',
      });
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Invalid credentials/);
  });

  it('should return 401 and error message for incorrect password', async () => {
    await registerTestUser();
    const res = await request(app)
      .post('/login')
      .send({
        email: testUser.email,
        password: 'WrongPassword123',
      });
    expect(res.statusCode).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.message).toMatch(/Invalid credentials/);
  });

  it('should block further login attempts after exceeding rate limit', async () => {
    await registerTestUser();
    // Exceed the rate limit (10 attempts)
    for (let i = 0; i < 10; i++) {
      await request(app)
        .post('/login')
        .send({
          email: testUser.email,
          password: 'WrongPassword123',
        });
    }
    // 11th attempt should be blocked
    const res = await request(app)
      .post('/login')
      .send({
        email: testUser.email,
        password: 'WrongPassword123',
      });
    expect(res.statusCode).toBe(429);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toMatch(/Too many login attempts/);
  });
});
