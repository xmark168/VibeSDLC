import { NextRequest, NextResponse } from 'next/server';
import { successResponse, errorResponse, handleError, handleZodError } from '@/lib/api-response';
import { registerSchema, RegisterResponse, ApiErrorCode, HttpStatus } from '@/types/api.types';
import { PrismaClient } from '@prisma/client';
import { ZodError } from 'zod';
// TODO: Implement a password hashing utility (e.g., bcrypt)
// import { hashPassword } from '@/lib/auth-utils'; 

const prisma = new PrismaClient();

export async function POST(request: NextRequest): Promise<NextResponse<RegisterResponse | any>> {
  try {
    const body = await request.json();

    // 1. Validate request body with Zod
    const validatedData = registerSchema.parse(body);
    const { username, password } = validatedData;

    // 2. Check if username already exists
    const existingUser = await prisma.user.findUnique({
      where: { username },
    });

    if (existingUser) {
      return errorResponse(
        {
          code: ApiErrorCode.CONFLICT,
          message: 'Username already exists',
        },
        HttpStatus.CONFLICT
      );
    }

    // 3. Hash password (placeholder for actual implementation)
    // In a real application, you would use a robust hashing library like bcrypt.
    const hashedPassword = `hashed_${password}`; // Placeholder
    // const hashedPassword = await hashPassword(password); 

    // 4. Create new user in the database
    const newUser = await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
      },
    });

    // 5. Return success response
    return successResponse<RegisterResponse>(
      {
        userId: newUser.id,
        username: newUser.username,
      },
      'User registered successfully', 
      HttpStatus.CREATED
    );
  } catch (error: any) {
    if (error instanceof ZodError) {
      return handleZodError(error);
    }
    return handleError(error);
  } finally {
    await prisma.$disconnect();
  }
}
