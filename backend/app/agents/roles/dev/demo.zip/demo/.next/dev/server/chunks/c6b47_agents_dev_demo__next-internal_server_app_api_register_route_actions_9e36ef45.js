module.exports = [
"[project]/services/ai-agent-service/app/agents/dev/demo/.next-internal/server/app/api/register/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=c6b47_agents_dev_demo__next-internal_server_app_api_register_route_actions_9e36ef45.js.map