module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/services/ai-agent-service/app/agents/dev/demo/src/types/api.types.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApiErrorCode",
    ()=>ApiErrorCode,
    "HttpStatus",
    ()=>HttpStatus,
    "registerSchema",
    ()=>registerSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/node_modules/.pnpm/zod@4.1.12/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
var HttpStatus = /*#__PURE__*/ function(HttpStatus) {
    HttpStatus[HttpStatus["OK"] = 200] = "OK";
    HttpStatus[HttpStatus["CREATED"] = 201] = "CREATED";
    HttpStatus[HttpStatus["NO_CONTENT"] = 204] = "NO_CONTENT";
    HttpStatus[HttpStatus["BAD_REQUEST"] = 400] = "BAD_REQUEST";
    HttpStatus[HttpStatus["UNAUTHORIZED"] = 401] = "UNAUTHORIZED";
    HttpStatus[HttpStatus["FORBIDDEN"] = 403] = "FORBIDDEN";
    HttpStatus[HttpStatus["NOT_FOUND"] = 404] = "NOT_FOUND";
    HttpStatus[HttpStatus["CONFLICT"] = 409] = "CONFLICT";
    HttpStatus[HttpStatus["UNPROCESSABLE_ENTITY"] = 422] = "UNPROCESSABLE_ENTITY";
    HttpStatus[HttpStatus["INTERNAL_SERVER_ERROR"] = 500] = "INTERNAL_SERVER_ERROR";
    return HttpStatus;
}({});
var ApiErrorCode = /*#__PURE__*/ function(ApiErrorCode) {
    ApiErrorCode["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ApiErrorCode["UNAUTHORIZED"] = "UNAUTHORIZED";
    ApiErrorCode["FORBIDDEN"] = "FORBIDDEN";
    ApiErrorCode["NOT_FOUND"] = "NOT_FOUND";
    ApiErrorCode["CONFLICT"] = "CONFLICT";
    ApiErrorCode["INTERNAL_ERROR"] = "INTERNAL_ERROR";
    ApiErrorCode["DATABASE_ERROR"] = "DATABASE_ERROR";
    return ApiErrorCode;
}({});
const registerSchema = __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    username: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(3, 'Username must be at least 3 characters long'),
    password: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(6, 'Password must be at least 6 characters long')
});
}),
"[project]/services/ai-agent-service/app/agents/dev/demo/src/lib/api-response.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API Response Helpers
 * Utility functions để tạo consistent API responses
 */ __turbopack_context__.s([
    "ApiErrors",
    ()=>ApiErrors,
    "ApiException",
    ()=>ApiException,
    "errorResponse",
    ()=>errorResponse,
    "handleError",
    ()=>handleError,
    "handleZodError",
    ()=>handleZodError,
    "successResponse",
    ()=>successResponse
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/src/types/api.types.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/node_modules/.pnpm/zod@4.1.12/node_modules/zod/v4/classic/errors.js [app-route] (ecmascript)");
;
;
;
function successResponse(data, message, status = __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].OK) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: true,
        data,
        message
    }, {
        status
    });
}
function errorResponse(error, status = __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].INTERNAL_SERVER_ERROR) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_$40$babel$2b$core$40$7$2e$28$2e$5_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        success: false,
        error
    }, {
        status
    });
}
function handleZodError(error) {
    const formattedErrors = error.issues.map((err)=>({
            field: err.path.join('.'),
            message: err.message
        }));
    return errorResponse({
        code: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].VALIDATION_ERROR,
        message: 'Dữ liệu không hợp lệ',
        details: {
            errors: formattedErrors
        }
    }, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].UNPROCESSABLE_ENTITY);
}
function handleError(error) {
    console.error('API Error:', error);
    // Zod validation error
    if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ZodError"]) {
        return handleZodError(error);
    }
    // Custom API error
    if (isApiError(error)) {
        return errorResponse({
            code: error.code,
            message: error.message,
            details: error.details
        }, error.status || __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].INTERNAL_SERVER_ERROR);
    }
    // Generic error
    const message = error instanceof Error ? error.message : 'Đã xảy ra lỗi không xác định';
    return errorResponse({
        code: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].INTERNAL_ERROR,
        message,
        stack: ("TURBOPACK compile-time truthy", 1) ? error.stack : "TURBOPACK unreachable"
    }, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].INTERNAL_SERVER_ERROR);
}
class ApiException extends Error {
    code;
    message;
    status;
    details;
    constructor(code, message, status = __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].INTERNAL_SERVER_ERROR, details){
        super(message), this.code = code, this.message = message, this.status = status, this.details = details;
        this.name = 'ApiException';
    }
}
/**
 * Type guard cho API error
 */ function isApiError(error) {
    return error instanceof ApiException;
}
const ApiErrors = {
    unauthorized: ()=>new ApiException(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].UNAUTHORIZED, 'Bạn cần đăng nhập để thực hiện hành động này', __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].UNAUTHORIZED),
    forbidden: ()=>new ApiException(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].FORBIDDEN, 'Bạn không có quyền thực hiện hành động này', __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].FORBIDDEN),
    notFound: (resource = 'Resource')=>new ApiException(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].NOT_FOUND, `${resource} không tồn tại`, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].NOT_FOUND),
    conflict: (message)=>new ApiException(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].CONFLICT, message, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].CONFLICT),
    validation: (message, details)=>new ApiException(__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].VALIDATION_ERROR, message, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].UNPROCESSABLE_ENTITY, details)
};
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/services/ai-agent-service/app/agents/dev/demo/src/app/api/register/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$lib$2f$api$2d$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/src/lib/api-response.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/src/types/api.types.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/ai-agent-service/app/agents/dev/demo/node_modules/.pnpm/zod@4.1.12/node_modules/zod/v4/classic/errors.js [app-route] (ecmascript)");
;
;
;
;
// TODO: Implement a password hashing utility (e.g., bcrypt)
// import { hashPassword } from '@/lib/auth-utils'; 
const prisma = new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]();
async function POST(request) {
    try {
        const body = await request.json();
        // 1. Validate request body with Zod
        const validatedData = __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerSchema"].parse(body);
        const { username, password } = validatedData;
        // 2. Check if username already exists
        const existingUser = await prisma.user.findUnique({
            where: {
                username
            }
        });
        if (existingUser) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$lib$2f$api$2d$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["errorResponse"])({
                code: __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ApiErrorCode"].CONFLICT,
                message: 'Username already exists'
            }, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].CONFLICT);
        }
        // 3. Hash password (placeholder for actual implementation)
        // In a real application, you would use a robust hashing library like bcrypt.
        const hashedPassword = `hashed_${password}`; // Placeholder
        // const hashedPassword = await hashPassword(password); 
        // 4. Create new user in the database
        const newUser = await prisma.user.create({
            data: {
                username,
                password: hashedPassword
            }
        });
        // 5. Return success response
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$lib$2f$api$2d$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["successResponse"])({
            userId: newUser.id,
            username: newUser.username
        }, 'User registered successfully', __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$types$2f$api$2e$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HttpStatus"].CREATED);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$12$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ZodError"]) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$lib$2f$api$2d$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["handleZodError"])(error);
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$ai$2d$agent$2d$service$2f$app$2f$agents$2f$dev$2f$demo$2f$src$2f$lib$2f$api$2d$response$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["handleError"])(error);
    } finally{
        await prisma.$disconnect();
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__046e5690._.js.map