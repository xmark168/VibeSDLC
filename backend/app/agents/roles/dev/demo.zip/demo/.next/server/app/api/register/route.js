var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__a152907b._.js")
R.c("server/chunks/[root-of-the-server]__87da7bfd._.js")
R.c("server/chunks/c6b47_agents_dev_demo__next-internal_server_app_api_register_route_actions_9e36ef45.js")
R.m(10067)
module.exports=R.m(10067).exports
