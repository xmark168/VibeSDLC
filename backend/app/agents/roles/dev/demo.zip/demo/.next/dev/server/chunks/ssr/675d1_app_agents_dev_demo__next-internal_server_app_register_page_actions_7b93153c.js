module.exports = [
"[project]/services/ai-agent-service/app/agents/dev/demo/.next-internal/server/app/register/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=675d1_app_agents_dev_demo__next-internal_server_app_register_page_actions_7b93153c.js.map