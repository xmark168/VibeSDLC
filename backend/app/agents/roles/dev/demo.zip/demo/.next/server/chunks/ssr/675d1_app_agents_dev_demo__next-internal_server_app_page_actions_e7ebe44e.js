module.exports=[48360,(a,b,c)=>{}];

//# sourceMappingURL=675d1_app_agents_dev_demo__next-internal_server_app_page_actions_e7ebe44e.js.map