globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d97af972fad70ef7.js",
    "static/chunks/c5c318e77dbc65b2.js",
    "static/chunks/e75ff89ddb153057.js",
    "static/chunks/8c308bbae09acf0b.js",
    "static/chunks/turbopack-5bc368e5bd6fec67.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];