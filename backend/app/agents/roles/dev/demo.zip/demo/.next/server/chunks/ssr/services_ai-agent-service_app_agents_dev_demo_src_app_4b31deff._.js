module.exports=[28332,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},67237,a=>{"use strict";let b={src:a.i(28332).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=services_ai-agent-service_app_agents_dev_demo_src_app_4b31deff._.js.map