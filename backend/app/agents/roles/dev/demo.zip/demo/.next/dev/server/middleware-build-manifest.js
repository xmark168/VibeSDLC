globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/4084b_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_57f4750b._.js",
    "static/chunks/4084b_next_dist_compiled_react-dom_72c594e8._.js",
    "static/chunks/4084b_next_dist_compiled_react-server-dom-turbopack_baab63ed._.js",
    "static/chunks/4084b_next_dist_compiled_next-devtools_index_be8238d4.js",
    "static/chunks/4084b_next_dist_compiled_77a698a3._.js",
    "static/chunks/4084b_next_dist_client_b058a6cd._.js",
    "static/chunks/4084b_next_dist_375d897a._.js",
    "static/chunks/f5c53_@swc_helpers_cjs_2ce9ae3c._.js",
    "static/chunks/services_ai-agent-service_app_agents_dev_demo_a0ff3932._.js",
    "static/chunks/turbopack-services_ai-agent-service_app_agents_dev_demo_00ce7669._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];