var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/4084b_next_1a7d35c4._.js")
R.c("server/chunks/861ba_zod_v4_6b5b9405._.js")
R.c("server/chunks/[root-of-the-server]__046e5690._.js")
R.c("server/chunks/c6b47_agents_dev_demo__next-internal_server_app_api_register_route_actions_9e36ef45.js")
R.m("[project]/services/ai-agent-service/app/agents/dev/demo/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/services/ai-agent-service/app/agents/dev/demo/src/app/api/register/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/services/ai-agent-service/app/agents/dev/demo/node_modules/.pnpm/next@16.0.3_@babel+core@7.28.5_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/services/ai-agent-service/app/agents/dev/demo/src/app/api/register/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
