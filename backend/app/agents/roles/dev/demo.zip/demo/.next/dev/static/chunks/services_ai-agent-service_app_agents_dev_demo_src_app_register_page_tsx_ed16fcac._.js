(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/c49d7_react-hook-form_dist_index_esm_mjs_36676c95._.js",
  "static/chunks/861ba_zod_v4_744a817f._.js",
  "static/chunks/0f352_tailwind-merge_dist_bundle-mjs_mjs_505b83fe._.js",
  "static/chunks/f135f__pnpm_994720af._.js",
  "static/chunks/services_ai-agent-service_app_agents_dev_demo_src_9f5c8b29._.js"
],
    source: "dynamic"
});
