module.exports=[83500,(a,b,c)=>{}];

//# sourceMappingURL=675d1_app_agents_dev_demo__next-internal_server_app_register_page_actions_7b93153c.js.map