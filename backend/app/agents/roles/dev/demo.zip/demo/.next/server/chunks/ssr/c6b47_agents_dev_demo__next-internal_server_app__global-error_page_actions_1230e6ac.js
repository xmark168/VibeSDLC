module.exports=[8585,(a,b,c)=>{}];

//# sourceMappingURL=c6b47_agents_dev_demo__next-internal_server_app__global-error_page_actions_1230e6ac.js.map