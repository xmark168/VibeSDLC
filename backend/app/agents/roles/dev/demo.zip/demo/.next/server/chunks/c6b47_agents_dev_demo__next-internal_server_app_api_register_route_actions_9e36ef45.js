module.exports=[16876,(e,o,d)=>{}];

//# sourceMappingURL=c6b47_agents_dev_demo__next-internal_server_app_api_register_route_actions_9e36ef45.js.map