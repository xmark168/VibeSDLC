var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__87da7bfd._.js")
R.c("server/chunks/4084b_next_dist_esm_build_templates_app-route_595dc8ed.js")
R.c("server/chunks/c6b47_agents_dev_demo__next-internal_server_app_favicon_ico_route_actions_e3707e4e.js")
R.m(71082)
module.exports=R.m(71082).exports
