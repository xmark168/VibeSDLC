(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_57f4750b._.js",
  "static/chunks/4084b_next_dist_compiled_react-dom_72c594e8._.js",
  "static/chunks/4084b_next_dist_compiled_react-server-dom-turbopack_baab63ed._.js",
  "static/chunks/4084b_next_dist_compiled_next-devtools_index_be8238d4.js",
  "static/chunks/4084b_next_dist_compiled_77a698a3._.js",
  "static/chunks/4084b_next_dist_client_b058a6cd._.js",
  "static/chunks/4084b_next_dist_375d897a._.js",
  "static/chunks/f5c53_@swc_helpers_cjs_2ce9ae3c._.js"
],
    source: "entry"
});
