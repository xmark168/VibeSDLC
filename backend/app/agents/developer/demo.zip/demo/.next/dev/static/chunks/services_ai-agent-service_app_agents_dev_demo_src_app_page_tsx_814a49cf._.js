(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f135f_aba82b05._.js",
  "static/chunks/services_ai-agent-service_app_agents_dev_demo_src_5ca169e6._.js"
],
    source: "dynamic"
});
