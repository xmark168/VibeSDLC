(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__5535beee._.css",
  "static/chunks/f135f_4c4c47c3._.js"
],
    source: "dynamic"
});
