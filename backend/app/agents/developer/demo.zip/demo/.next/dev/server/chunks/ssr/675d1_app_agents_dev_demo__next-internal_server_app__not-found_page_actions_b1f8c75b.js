module.exports = [
"[project]/services/ai-agent-service/app/agents/dev/demo/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=675d1_app_agents_dev_demo__next-internal_server_app__not-found_page_actions_b1f8c75b.js.map