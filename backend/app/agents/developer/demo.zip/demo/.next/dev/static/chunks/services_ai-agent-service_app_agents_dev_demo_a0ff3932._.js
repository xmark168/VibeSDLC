(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c61ffac9._.js",
  "static/chunks/f135f_next_dist_compiled_react-dom_29f44235._.js",
  "static/chunks/f135f_next_dist_compiled_react-server-dom-turbopack_131cddd0._.js",
  "static/chunks/f135f_next_dist_compiled_next-devtools_index_899a4509.js",
  "static/chunks/f135f_next_dist_compiled_c154de89._.js",
  "static/chunks/f135f_next_dist_client_b00fec64._.js",
  "static/chunks/f135f_next_dist_7429b6f8._.js",
  "static/chunks/f135f_@swc_helpers_cjs_3fe2ab09._.js"
],
    source: "entry"
});
