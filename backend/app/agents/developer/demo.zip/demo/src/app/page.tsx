import { HomepageContent } from "@/components/HomepageContent";

export default function Home() {
  return (
    <main className="min-h-screen">
      <HomepageContent />
    </main>
  );
}